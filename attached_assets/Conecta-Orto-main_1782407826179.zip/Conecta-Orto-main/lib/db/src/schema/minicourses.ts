import { pgTable, serial, text } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const minicoursesTable = pgTable("minicourses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  instructor: text("instructor").notNull(),
  duration: text("duration").notNull(),
});

export const insertMinicourseSchema = createInsertSchema(minicoursesTable).omit({ id: true });
export type InsertMinicourse = z.infer<typeof insertMinicourseSchema>;
export type Minicourse = typeof minicoursesTable.$inferSelect;
