import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Mic, BookOpen, Coffee, Users } from "lucide-react";

const schedule = [
  { time: "08h00", label: "Credenciamento e recepção", type: "logistics", icon: Users },
  { time: "08h30", label: "Cerimônia de abertura", sub: "Prof. Silvio Gobbi", type: "opening", icon: Mic },
  {
    time: "09h00",
    label: "Palestra 1",
    sub: "Implantes Ortopédicos: o que são, como funcionam e por que não devem causar medo",
    speaker: "Profa. Dra. Ana Paula Ferreira",
    type: "talk",
    icon: Mic,
  },
  { time: "10h00", label: "Coffee Break", type: "break", icon: Coffee },
  {
    time: "10h15",
    label: "Palestra 2",
    sub: "Materiais Biocompatíveis — do Titânio à Impressão 3D",
    speaker: "Prof. Dr. Carlos Eduardo Mendes",
    type: "talk",
    icon: Mic,
  },
  {
    time: "11h15",
    label: "Minicurso 1",
    sub: "Introdução aos Implantes Ortopédicos",
    location: "Sala A",
    type: "minicourse",
    icon: BookOpen,
  },
  { time: "12h30", label: "Almoço", type: "break", icon: Coffee },
  {
    time: "13h30",
    label: "Palestra 3",
    sub: "A Engenharia de Software no apoio à Medicina — sistemas, softwares e inovação",
    speaker: "Prof. Silvio Gobbi",
    type: "talk",
    icon: Mic,
  },
  {
    time: "14h30",
    label: "Minicurso 2",
    sub: "Materiais Biocompatíveis e Titânio",
    location: "Sala B",
    type: "minicourse",
    icon: BookOpen,
  },
  { time: "15h45", label: "Coffee Break", type: "break", icon: Coffee },
  {
    time: "16h00",
    label: "Mesa Redonda",
    sub: "Mitos e verdades sobre implantes — perguntas da comunidade",
    type: "roundtable",
    icon: Users,
  },
  { time: "17h00", label: "Encerramento e certificação", type: "closing", icon: Calendar },
  { time: "18h00", label: "Confraternização", type: "logistics", icon: Users },
];

const typeConfig: Record<string, { color: string; badge: string; badgeClass: string }> = {
  logistics:   { color: "border-slate-200 bg-slate-50",      badge: "Logística",     badgeClass: "bg-slate-100 text-slate-600 border-slate-200" },
  opening:     { color: "border-blue-200 bg-blue-50",        badge: "Abertura",      badgeClass: "bg-blue-100 text-blue-700 border-blue-200" },
  talk:        { color: "border-blue-300 bg-white",          badge: "Palestra",      badgeClass: "bg-blue-600 text-white border-blue-700" },
  break:       { color: "border-amber-100 bg-amber-50/50",   badge: "Intervalo",     badgeClass: "bg-amber-100 text-amber-700 border-amber-200" },
  minicourse:  { color: "border-indigo-200 bg-indigo-50/50", badge: "Minicurso",     badgeClass: "bg-indigo-100 text-indigo-700 border-indigo-200" },
  roundtable:  { color: "border-teal-200 bg-teal-50/50",     badge: "Mesa Redonda",  badgeClass: "bg-teal-100 text-teal-700 border-teal-200" },
  closing:     { color: "border-green-200 bg-green-50/50",   badge: "Encerramento",  badgeClass: "bg-green-100 text-green-700 border-green-200" },
};

export default function Programacao() {
  return (
    <div className="container mx-auto px-4 py-12 max-w-3xl">
      <div className="text-center mb-12">
        <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-sm font-medium mb-4 border border-blue-100">
          <Calendar className="h-4 w-4" />
          18 de Junho de 2025
        </span>
        <h1 className="text-3xl font-bold text-slate-900 mb-3">Programação do Congresso</h1>
        <p className="text-slate-500 text-lg">
          Um dia completo dedicado a desmistificar os implantes ortopédicos para a comunidade.
        </p>
      </div>

      <div className="relative">
        {/* Timeline line */}
        <div className="absolute left-[4.5rem] top-0 bottom-0 w-px bg-slate-200 hidden sm:block" />

        <div className="space-y-4">
          {schedule.map((item, i) => {
            const config = typeConfig[item.type] ?? typeConfig.logistics;
            const Icon = item.icon;
            return (
              <div key={i} className="flex gap-4 sm:gap-6 items-start group">
                {/* Time column */}
                <div className="w-20 shrink-0 text-right hidden sm:block">
                  <span className="text-sm font-mono font-semibold text-slate-500 group-hover:text-blue-600 transition-colors">
                    {item.time}
                  </span>
                </div>

                {/* Dot */}
                <div className="hidden sm:flex w-3 h-3 rounded-full bg-blue-400 border-2 border-white shadow-sm mt-4 shrink-0 z-10" />

                {/* Content card */}
                <div className={`flex-1 rounded-xl border p-4 sm:p-5 transition-shadow hover:shadow-sm ${config.color}`}>
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-lg hidden sm:flex shrink-0 ${config.badgeClass} bg-opacity-20`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <span className="sm:hidden text-xs font-mono font-semibold text-slate-500 flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {item.time}
                        </span>
                        <Badge variant="outline" className={`text-xs ${config.badgeClass}`}>
                          {config.badge}
                        </Badge>
                      </div>
                      <p className="font-semibold text-slate-900">{item.label}</p>
                      {item.sub && (
                        <p className="text-slate-600 text-sm mt-0.5">{item.sub}</p>
                      )}
                      {item.speaker && (
                        <p className="text-slate-500 text-xs mt-1 font-medium">{item.speaker}</p>
                      )}
                      {item.location && (
                        <p className="text-slate-500 text-xs mt-1">{item.location}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
