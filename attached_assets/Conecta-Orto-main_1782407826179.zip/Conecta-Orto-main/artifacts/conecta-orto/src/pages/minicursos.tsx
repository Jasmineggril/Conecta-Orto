import { useState } from "react";
import {
  useListMinicourses,
  useEnrollMinicourse,
  useCheckRegistration,
  getListMinicoursesQueryKey,
  getCheckRegistrationQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, Users, Clock, CheckCircle, AlertCircle, Search } from "lucide-react";
import { Link } from "wouter";

export default function Minicursos() {
  const [email, setEmail] = useState("");
  const [inputEmail, setInputEmail] = useState("");
  const [enrollSuccess, setEnrollSuccess] = useState<Record<number, boolean>>({});
  const [enrollErrors, setEnrollErrors] = useState<Record<number, string>>({});
  const queryClient = useQueryClient();

  const { data: minicourses, isLoading } = useListMinicourses();
  const { data: regCheck } = useCheckRegistration(
    { email },
    { query: { enabled: email.length > 3 } }
  );
  const enrollMutation = useEnrollMinicourse();

  const handleCheckEmail = (e: React.FormEvent) => {
    e.preventDefault();
    setEmail(inputEmail.trim());
  };

  const handleEnroll = (minicourseId: number) => {
    if (!email) return;
    setEnrollErrors((prev) => ({ ...prev, [minicourseId]: "" }));
    enrollMutation.mutate(
      { id: minicourseId, data: { email } },
      {
        onSuccess: () => {
          setEnrollSuccess((prev) => ({ ...prev, [minicourseId]: true }));
          queryClient.invalidateQueries({ queryKey: getListMinicoursesQueryKey() });
          queryClient.invalidateQueries({ queryKey: getCheckRegistrationQueryKey({ email }) });
        },
        onError: (err: unknown) => {
          const e = err as { data?: { error?: string } };
          setEnrollErrors((prev) => ({
            ...prev,
            [minicourseId]: e?.data?.error ?? "Erro ao se inscrever. Tente novamente.",
          }));
        },
      }
    );
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <div className="text-center mb-10">
        <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-sm font-medium mb-4 border border-blue-100">
          <GraduationCap className="h-4 w-4" />
          Minicursos Especializados
        </span>
        <h1 className="text-3xl font-bold text-slate-900 mb-3">Minicursos</h1>
        <p className="text-slate-500 text-lg max-w-xl mx-auto">
          Aprofunde seu conhecimento em sessões práticas e interativas. Para se inscrever em um minicurso, você precisa estar inscrito no evento.
        </p>
      </div>

      {/* Email verification */}
      <Card className="mb-10 border-blue-100 bg-blue-50/50">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Search className="h-5 w-5 text-blue-600" />
            Identifique-se para se inscrever
          </CardTitle>
          <CardDescription>
            Informe seu e-mail de inscrição no evento para habilitar a inscrição nos minicursos.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCheckEmail} className="flex gap-3 flex-col sm:flex-row">
            <div className="flex-1 space-y-1">
              <Label htmlFor="check-email" className="sr-only">E-mail</Label>
              <Input
                id="check-email"
                type="email"
                placeholder="seu@email.com"
                value={inputEmail}
                onChange={(e) => setInputEmail(e.target.value)}
                className="bg-white"
              />
            </div>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white">
              Verificar
            </Button>
          </form>

          {email && regCheck && (
            <div className="mt-4">
              {regCheck.registered ? (
                <div className="flex items-center gap-2 text-green-700 bg-green-50 border border-green-200 rounded-lg px-4 py-3">
                  <CheckCircle className="h-5 w-5 shrink-0" />
                  <span className="text-sm font-medium">
                    Olá, <strong>{regCheck.name}</strong>! Você está inscrito(a) no evento. Pode se inscrever nos minicursos abaixo.
                  </span>
                </div>
              ) : (
                <div className="flex items-start gap-2 text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-4 py-3">
                  <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
                  <div className="text-sm">
                    E-mail não encontrado nas inscrições do evento.{" "}
                    <Link href="/inscricao" className="font-semibold underline hover:no-underline">
                      Inscreva-se no evento primeiro
                    </Link>{" "}
                    para depois se inscrever nos minicursos.
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Minicourses list */}
      {isLoading ? (
        <div className="flex items-center justify-center py-16">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-1">
          {minicourses?.map((course, index) => (
            <Card key={course.id} className="overflow-hidden border hover:shadow-md transition-shadow">
              <div className="h-1.5 bg-gradient-to-r from-blue-600 to-blue-400" />
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="secondary" className="text-xs">
                        Minicurso {index + 1}
                      </Badge>
                    </div>
                    <CardTitle className="text-xl mb-1">{course.name}</CardTitle>
                    <p className="text-slate-500 text-sm">{course.instructor}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-slate-600 leading-relaxed">{course.description}</p>

                <div className="flex flex-wrap gap-4 text-sm text-slate-500">
                  <div className="flex items-center gap-1.5">
                    <Clock className="h-4 w-4 text-blue-500" />
                    <span>{course.duration}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Users className="h-4 w-4 text-blue-500" />
                    <span>{course.enrollmentCount} {course.enrollmentCount === 1 ? "inscrito" : "inscritos"}</span>
                  </div>
                </div>

                {enrollErrors[course.id] && (
                  <div className="flex items-start gap-2 text-red-600 bg-red-50 border border-red-200 rounded-lg px-4 py-3 text-sm">
                    <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                    {enrollErrors[course.id]}
                  </div>
                )}

                {enrollSuccess[course.id] ? (
                  <div className="flex items-center gap-2 text-green-700 bg-green-50 border border-green-200 rounded-lg px-4 py-3 text-sm">
                    <CheckCircle className="h-4 w-4" />
                    Inscrição no minicurso confirmada!
                  </div>
                ) : (
                  <Button
                    className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white"
                    disabled={!email || !regCheck?.registered || enrollMutation.isPending}
                    onClick={() => handleEnroll(course.id)}
                  >
                    {enrollMutation.isPending ? "Processando..." : "Inscrever-se neste Minicurso"}
                  </Button>
                )}

                {!email && (
                  <p className="text-xs text-slate-400">
                    Informe seu e-mail acima para habilitar a inscrição.
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
