import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Calendar, MapPin, Users, BookOpen, Award } from "lucide-react";

export default function Home() {
  return (
    <div className="flex flex-col gap-16 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-slate-900 text-white py-24 sm:py-32">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?q=80&w=2000')] bg-cover bg-center opacity-10 mix-blend-overlay"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/90 to-slate-900/90"></div>
        
        <div className="container mx-auto px-4 relative z-10 text-center flex flex-col items-center">
          <span className="px-4 py-1.5 rounded-full bg-blue-500/20 text-blue-200 text-sm font-medium mb-6 border border-blue-400/30">
            Congresso Aberto à Comunidade
          </span>
          <h1 className="text-4xl sm:text-6xl font-bold tracking-tight mb-6 max-w-4xl">
            Conecta Orto: O Futuro dos <span className="text-blue-400">Implantes Ortopédicos</span>
          </h1>
          <p className="text-lg sm:text-xl text-slate-300 max-w-2xl mb-10">
            Desmistificando a tecnologia que devolve movimento. Um evento acolhedor para pacientes, curiosos e futuros profissionais da saúde.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center gap-4 justify-center w-full max-w-md">
            <Link href="/inscricao" className="w-full sm:w-auto">
              <Button size="lg" className="w-full sm:w-auto bg-blue-600 hover:bg-blue-500 text-white font-semibold">
                Inscreva-se Gratuitamente
              </Button>
            </Link>
            <div className="flex gap-4 w-full sm:w-auto">
              <Link href="/minicursos" className="flex-1">
                <Button size="lg" variant="outline" className="w-full bg-white/10 border-white/20 hover:bg-white/20 text-white">
                  Minicursos
                </Button>
              </Link>
              <Link href="/certificados" className="flex-1">
                <Button size="lg" variant="outline" className="w-full bg-white/10 border-white/20 hover:bg-white/20 text-white">
                  Certificados
                </Button>
              </Link>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-8 mt-16 text-sm sm:text-base text-slate-300">
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-blue-400" />
              18 de Junho de 2025
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-blue-400" />
              Auditório Principal
            </div>
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-400" />
              Aberto ao Público
            </div>
          </div>
        </div>
      </section>

      {/* Info Section */}
      <section className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Sobre os Implantes</h2>
            <p className="text-slate-600 text-lg leading-relaxed">
              Muitas pessoas sentem receio quando ouvem a palavra "implante". Nossa missão é trazer clareza e tranquilidade.
            </p>
            <p className="text-slate-600 text-lg leading-relaxed">
              Descubra como os materiais biocompatíveis evoluíram do titânio à impressão 3D, e como a engenharia e a medicina trabalham juntas para devolver qualidade de vida.
            </p>
            <Link href="/programacao" className="inline-flex items-center text-blue-600 font-medium hover:text-blue-700 transition-colors">
              Ver a programação completa <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
          <div className="rounded-2xl overflow-hidden shadow-2xl aspect-video bg-slate-100 flex items-center justify-center relative">
            <div className="absolute inset-0 bg-slate-200 flex flex-col items-center justify-center text-slate-400">
              {/* YouTube Iframe Placeholder */}
              <iframe 
                width="100%" 
                height="100%" 
                src="https://www.youtube.com/embed/dQw4w9WgXcQ" 
                title="Conecta Orto Teaser" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowFullScreen
                className="absolute inset-0"
              ></iframe>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Schedule */}
      <section className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-10 text-slate-900">O que esperar</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="bg-blue-50/50 border-blue-100">
            <CardContent className="pt-6">
              <BookOpen className="h-10 w-10 text-blue-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Palestras Acessíveis</h3>
              <p className="text-slate-600">Especialistas explicam o funcionamento dos implantes de forma simples e direta, sem jargões complexos.</p>
            </CardContent>
          </Card>
          <Card className="bg-blue-50/50 border-blue-100">
            <CardContent className="pt-6">
              <Users className="h-10 w-10 text-blue-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Mesa Redonda</h3>
              <p className="text-slate-600">Um espaço seguro para tirar dúvidas, desfazer mitos e entender as verdades sobre os procedimentos.</p>
            </CardContent>
          </Card>
          <Card className="bg-blue-50/50 border-blue-100">
            <CardContent className="pt-6">
              <Award className="h-10 w-10 text-blue-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Minicursos Práticos</h3>
              <p className="text-slate-600">Sessões focadas para quem deseja entender mais a fundo os materiais e as tecnologias envolvidas.</p>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
