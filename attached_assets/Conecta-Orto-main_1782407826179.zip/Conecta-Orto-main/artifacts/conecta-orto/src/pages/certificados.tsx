import { useState } from "react";
import { useGetCertificates } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Award, Search, CheckCircle, AlertCircle, Stethoscope, GraduationCap } from "lucide-react";

export default function Certificados() {
  const [inputEmail, setInputEmail] = useState("");
  const [searchEmail, setSearchEmail] = useState("");

  const { data, isLoading, isError } = useGetCertificates(
    { email: searchEmail },
    { query: { enabled: searchEmail.length > 3 } }
  );

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchEmail(inputEmail.trim());
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-2xl">
      <div className="text-center mb-10">
        <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-sm font-medium mb-4 border border-blue-100">
          <Award className="h-4 w-4" />
          Certificados de Participação
        </span>
        <h1 className="text-3xl font-bold text-slate-900 mb-3">Seus Certificados</h1>
        <p className="text-slate-500 text-lg">
          Informe o e-mail usado na inscrição para visualizar seus certificados de participação.
        </p>
      </div>

      <Card className="mb-8 shadow-sm">
        <CardContent className="pt-6">
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="cert-email">E-mail de inscrição</Label>
              <div className="flex gap-3">
                <Input
                  id="cert-email"
                  type="email"
                  placeholder="seu@email.com"
                  value={inputEmail}
                  onChange={(e) => setInputEmail(e.target.value)}
                  className="flex-1"
                />
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white shrink-0">
                  <Search className="h-4 w-4 mr-2" />
                  Buscar
                </Button>
              </div>
            </div>
          </form>
        </CardContent>
      </Card>

      {isLoading && (
        <div className="flex items-center justify-center py-16">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      )}

      {isError && searchEmail && (
        <div className="flex items-start gap-3 p-5 bg-amber-50 border border-amber-200 rounded-xl text-amber-700">
          <AlertCircle className="h-5 w-5 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold">Nenhuma inscrição encontrada</p>
            <p className="text-sm mt-1">
              Não encontramos nenhum cadastro com o e-mail <strong>{searchEmail}</strong>. Verifique o e-mail ou realize sua inscrição no evento.
            </p>
          </div>
        </div>
      )}

      {data && (
        <div className="space-y-6">
          {/* Participant info */}
          <div className="p-5 bg-slate-50 rounded-xl border border-slate-200">
            <p className="text-sm text-slate-500 mb-1">Participante</p>
            <p className="text-xl font-bold text-slate-900">{data.participant.name}</p>
            <p className="text-slate-500 text-sm">{data.participant.email}</p>
          </div>

          {/* Event certificate */}
          <Card className="overflow-hidden border-2 border-blue-200 shadow-md">
            <div className="bg-gradient-to-r from-blue-700 to-blue-500 px-6 py-4">
              <div className="flex items-center gap-3 text-white">
                <Stethoscope className="h-6 w-6" />
                <div>
                  <p className="text-xs font-medium text-blue-200 uppercase tracking-wider">Certificado de Participação</p>
                  <p className="font-bold text-lg">Congresso</p>
                </div>
              </div>
            </div>
            <CardContent className="pt-6 pb-6">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <h3 className="font-bold text-slate-900 text-lg mb-1">
                    {data.eventCertificate.eventName}
                  </h3>
                  <p className="text-slate-500 text-sm">{data.eventCertificate.date}</p>
                  <p className="text-slate-500 text-sm mt-1">Participante: {data.participant.name}</p>
                </div>
                <Badge className="bg-green-100 text-green-700 border-green-200 shrink-0 flex items-center gap-1 px-3 py-1.5">
                  <CheckCircle className="h-4 w-4" />
                  Emitido
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Minicourse certificates */}
          {data.minicourseCertificates.length > 0 ? (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                <GraduationCap className="h-5 w-5 text-blue-600" />
                Certificados de Minicursos
              </h2>
              {data.minicourseCertificates.map((cert) => (
                <Card key={cert.minicourseId} className="overflow-hidden border border-slate-200">
                  <div className="bg-gradient-to-r from-slate-700 to-slate-600 px-6 py-4">
                    <div className="flex items-center gap-3 text-white">
                      <GraduationCap className="h-5 w-5" />
                      <div>
                        <p className="text-xs font-medium text-slate-300 uppercase tracking-wider">Certificado de Minicurso</p>
                        <p className="font-bold">{cert.minicourseName}</p>
                      </div>
                    </div>
                  </div>
                  <CardContent className="pt-5 pb-5">
                    <div className="flex items-center justify-between gap-4">
                      <div>
                        <p className="text-slate-600 text-sm">Participante: {data.participant.name}</p>
                        <p className="text-slate-500 text-sm">Conecta Orto — 18 de Junho de 2025</p>
                      </div>
                      <Badge className="bg-green-100 text-green-700 border-green-200 shrink-0 flex items-center gap-1 px-3 py-1.5">
                        <CheckCircle className="h-4 w-4" />
                        Emitido
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="p-5 bg-slate-50 rounded-xl border border-slate-100 text-center">
              <GraduationCap className="h-10 w-10 text-slate-300 mx-auto mb-3" />
              <p className="text-slate-500 text-sm">
                Nenhum minicurso registrado para este participante.{" "}
                <a href="/minicursos" className="text-blue-600 hover:underline font-medium">
                  Inscreva-se em um minicurso
                </a>.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
