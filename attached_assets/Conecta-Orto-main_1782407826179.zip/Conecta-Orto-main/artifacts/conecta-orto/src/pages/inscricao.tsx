import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCreateRegistration, useGetStats, getGetStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Users, CheckCircle, AlertCircle, ClipboardList } from "lucide-react";

const schema = z.object({
  name: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  email: z.string().email("E-mail inválido"),
  phone: z.string().min(8, "Telefone inválido"),
  city: z.string().optional(),
  profession: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

export default function Inscricao() {
  const [success, setSuccess] = useState<{ name: string; email: string } | null>(null);
  const [apiError, setApiError] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const { data: stats } = useGetStats();
  const mutation = useCreateRegistration();

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<FormData>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: FormData) => {
    setApiError(null);
    mutation.mutate(
      { data: { name: data.name, email: data.email, phone: data.phone, city: data.city, profession: data.profession } },
      {
        onSuccess: (created) => {
          setSuccess({ name: created.name, email: created.email });
          reset();
          queryClient.invalidateQueries({ queryKey: getGetStatsQueryKey() });
        },
        onError: (err: unknown) => {
          const e = err as { data?: { error?: string } };
          setApiError(e?.data?.error ?? "Erro ao realizar inscrição. Tente novamente.");
        },
      }
    );
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-2xl">
      <div className="text-center mb-10">
        <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-sm font-medium mb-4 border border-blue-100">
          <ClipboardList className="h-4 w-4" />
          Inscrição Gratuita
        </span>
        <h1 className="text-3xl font-bold text-slate-900 mb-3">Inscreva-se no Evento</h1>
        <p className="text-slate-500 text-lg">
          Garanta sua vaga no Congresso Conecta Orto. A inscrição é gratuita e aberta ao público.
        </p>
      </div>

      {stats && (
        <div className="flex items-center justify-center gap-2 mb-8 p-4 bg-blue-50 rounded-xl border border-blue-100">
          <Users className="h-5 w-5 text-blue-600" />
          <span className="text-blue-800 font-semibold">
            {stats.totalRegistrations} {stats.totalRegistrations === 1 ? "pessoa inscrita" : "pessoas inscritas"}
          </span>
          <span className="text-blue-600">no evento</span>
        </div>
      )}

      {success ? (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="pt-8 pb-8 text-center">
            <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-green-800 mb-2">Inscrição Confirmada!</h2>
            <p className="text-green-700 mb-1">
              Olá, <strong>{success.name}</strong>!
            </p>
            <p className="text-green-600 text-sm mb-6">
              Sua inscrição foi registrada com o e-mail <strong>{success.email}</strong>.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button
                variant="outline"
                className="border-green-400 text-green-700 hover:bg-green-100"
                onClick={() => setSuccess(null)}
              >
                Fazer outra inscrição
              </Button>
              <Button
                className="bg-green-600 hover:bg-green-700 text-white"
                onClick={() => (window.location.href = "/minicursos")}
              >
                Ver Minicursos
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-xl">Dados para inscrição</CardTitle>
            <CardDescription>Preencha os campos abaixo para garantir sua participação.</CardDescription>
          </CardHeader>
          <CardContent>
            {apiError && (
              <div className="flex items-start gap-3 p-4 mb-6 bg-red-50 border border-red-200 rounded-lg text-red-700">
                <AlertCircle className="h-5 w-5 mt-0.5 shrink-0" />
                <span className="text-sm">{apiError}</span>
              </div>
            )}
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
              <div className="space-y-1.5">
                <Label htmlFor="name">Nome completo *</Label>
                <Input id="name" placeholder="Seu nome completo" {...register("name")} />
                {errors.name && <p className="text-red-500 text-sm">{errors.name.message}</p>}
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="email">E-mail *</Label>
                <Input id="email" type="email" placeholder="seu@email.com" {...register("email")} />
                {errors.email && <p className="text-red-500 text-sm">{errors.email.message}</p>}
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="phone">Telefone *</Label>
                <Input id="phone" placeholder="(11) 99999-9999" {...register("phone")} />
                {errors.phone && <p className="text-red-500 text-sm">{errors.phone.message}</p>}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="city">Cidade <span className="text-slate-400 text-xs">(opcional)</span></Label>
                  <Input id="city" placeholder="Sua cidade" {...register("city")} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="profession">Profissão/Curso <span className="text-slate-400 text-xs">(opcional)</span></Label>
                  <Input id="profession" placeholder="Ex: Estudante de Eng. de Software" {...register("profession")} />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 text-base"
                disabled={mutation.isPending}
              >
                {mutation.isPending ? "Processando..." : "Confirmar Inscrição"}
              </Button>

              <p className="text-center text-xs text-slate-400">
                Campos marcados com * são obrigatórios. A inscrição é gratuita.
              </p>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
