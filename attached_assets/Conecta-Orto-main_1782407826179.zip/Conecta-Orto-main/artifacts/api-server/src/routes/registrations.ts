import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, registrationsTable } from "@workspace/db";
import {
  CreateRegistrationBody,
  CheckRegistrationQueryParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const registrations = await db.select().from(registrationsTable).orderBy(registrationsTable.createdAt);
    res.json(registrations.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
  } catch (err) {
    req.log.error({ err }, "Failed to list registrations");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/", async (req, res) => {
  const parsed = CreateRegistrationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }
  const { name, email, phone, city, profession } = parsed.data;
  try {
    const existing = await db.select().from(registrationsTable).where(eq(registrationsTable.email, email));
    if (existing.length > 0) {
      res.status(409).json({ error: "Este e-mail já está cadastrado no evento." });
      return;
    }
    const [created] = await db
      .insert(registrationsTable)
      .values({ name, email, phone, city: city ?? null, profession: profession ?? null })
      .returning();
    res.status(201).json({ ...created, createdAt: created.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to create registration");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/check", async (req, res) => {
  const parsed = CheckRegistrationQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Email is required" });
    return;
  }
  const { email } = parsed.data;
  try {
    const [reg] = await db.select().from(registrationsTable).where(eq(registrationsTable.email, email));
    if (!reg) {
      res.json({ registered: false, registrationId: null, name: null });
    } else {
      res.json({ registered: true, registrationId: reg.id, name: reg.name });
    }
  } catch (err) {
    req.log.error({ err }, "Failed to check registration");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
