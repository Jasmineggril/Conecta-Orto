import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, registrationsTable, enrollmentsTable, minicoursesTable } from "@workspace/db";
import { GetCertificatesQueryParams } from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  const parsed = GetCertificatesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Email is required" });
    return;
  }
  const { email } = parsed.data;
  try {
    const [participant] = await db.select().from(registrationsTable).where(eq(registrationsTable.email, email));
    if (!participant) {
      res.status(404).json({ error: "Nenhuma inscrição encontrada para este e-mail." });
      return;
    }
    const enrollments = await db
      .select({ enrollment: enrollmentsTable, minicourse: minicoursesTable })
      .from(enrollmentsTable)
      .innerJoin(minicoursesTable, eq(enrollmentsTable.minicourseId, minicoursesTable.id))
      .where(eq(enrollmentsTable.registrationId, participant.id));
    res.json({
      participant: { ...participant, createdAt: participant.createdAt.toISOString() },
      eventCertificate: {
        issued: true,
        eventName: "Conecta Orto: O Futuro dos Implantes Ortopédicos",
        date: "18 de Junho de 2025",
      },
      minicourseCertificates: enrollments.map((e) => ({
        minicourseId: e.minicourse.id,
        minicourseName: e.minicourse.name,
        issued: true,
      })),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get certificates");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
