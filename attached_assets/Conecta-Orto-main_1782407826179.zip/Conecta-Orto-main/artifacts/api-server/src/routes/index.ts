import { Router, type IRouter } from "express";
import healthRouter from "./health";
import registrationsRouter from "./registrations";
import minicoursesRouter from "./minicourses";
import certificatesRouter from "./certificates";
import statsRouter from "./stats";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/registrations", registrationsRouter);
router.use("/minicourses", minicoursesRouter);
router.use("/certificates", certificatesRouter);
router.use("/stats", statsRouter);

export default router;
