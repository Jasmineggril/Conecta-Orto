import { Router } from "express";
import { sql } from "drizzle-orm";
import { db, registrationsTable, enrollmentsTable, minicoursesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const [{ count: totalRegistrations }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(registrationsTable);
    const [{ count: totalMinicourseEnrollments }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(enrollmentsTable);
    const breakdown = await db
      .select({
        minicourseId: minicoursesTable.id,
        minicourseName: minicoursesTable.name,
        count: sql<number>`count(${enrollmentsTable.id})::int`,
      })
      .from(minicoursesTable)
      .leftJoin(enrollmentsTable, eq(enrollmentsTable.minicourseId, minicoursesTable.id))
      .groupBy(minicoursesTable.id, minicoursesTable.name);
    res.json({ totalRegistrations, totalMinicourseEnrollments, minicourseBreakdown: breakdown });
  } catch (err) {
    req.log.error({ err }, "Failed to get stats");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
