import { Router } from "express";
import { eq, and, sql } from "drizzle-orm";
import { db, minicoursesTable, enrollmentsTable, registrationsTable } from "@workspace/db";
import { EnrollMinicourseParams, EnrollMinicourseBody } from "@workspace/api-zod";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const minicourses = await db.select().from(minicoursesTable);
    const enrollmentCounts = await db
      .select({ minicourseId: enrollmentsTable.minicourseId, count: sql<number>`count(*)::int` })
      .from(enrollmentsTable)
      .groupBy(enrollmentsTable.minicourseId);
    const countMap = new Map(enrollmentCounts.map((e) => [e.minicourseId, e.count]));
    res.json(minicourses.map((m) => ({ ...m, enrollmentCount: countMap.get(m.id) ?? 0 })));
  } catch (err) {
    req.log.error({ err }, "Failed to list minicourses");
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/:id/enroll", async (req, res) => {
  const paramsParsed = EnrollMinicourseParams.safeParse({ id: Number(req.params.id) });
  if (!paramsParsed.success) {
    res.status(400).json({ error: "Invalid minicourse ID" });
    return;
  }
  const bodyParsed = EnrollMinicourseBody.safeParse(req.body);
  if (!bodyParsed.success) {
    res.status(400).json({ error: "Email is required" });
    return;
  }
  const { id } = paramsParsed.data;
  const { email } = bodyParsed.data;
  try {
    const [minicourse] = await db.select().from(minicoursesTable).where(eq(minicoursesTable.id, id));
    if (!minicourse) {
      res.status(404).json({ error: "Minicurso não encontrado." });
      return;
    }
    const [registration] = await db.select().from(registrationsTable).where(eq(registrationsTable.email, email));
    if (!registration) {
      res.status(400).json({ error: "Você precisa se inscrever no evento antes de se inscrever em um minicurso." });
      return;
    }
    const existing = await db.select().from(enrollmentsTable).where(
      and(eq(enrollmentsTable.registrationId, registration.id), eq(enrollmentsTable.minicourseId, id))
    );
    if (existing.length > 0) {
      res.status(400).json({ error: "Você já está inscrito neste minicurso." });
      return;
    }
    const [enrollment] = await db
      .insert(enrollmentsTable)
      .values({ registrationId: registration.id, minicourseId: id })
      .returning();
    res.status(201).json({ ...enrollment, enrolledAt: enrollment.enrolledAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to enroll in minicourse");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
